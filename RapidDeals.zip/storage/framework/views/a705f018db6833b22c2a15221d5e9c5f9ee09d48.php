<html>
    <head>
        <title>A User Send an Career Enqury</title>
    </head>
    <body>
        <p>Hi Rapid Deals,</p>
        <table>
            <tr><td>Name</td><td><?php echo e($fullname); ?></td></tr>
            <tr><td>Email</td><td><?php echo e($email); ?></td></tr>
            <tr><td>Phone</td><td><?php echo e($phone); ?></td></tr>
            <tr><td>course</td><td><?php echo e($course); ?></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>description</td><td><?php echo e($description); ?></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Thanks & Regards,</td></tr>
            <tr><td><?php echo e($fullname); ?></td></tr>
        </table>
    </body>
</html><?php /**PATH /home/b81baw0coev3/public_html/rapidleads.buzzsummo.net/resources/views/emails/career_temp.blade.php ENDPATH**/ ?>