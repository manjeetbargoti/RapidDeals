<html>
    <head>
        <title>A User Generate a Query</title>
    </head>
    <body>
        <p>Hi Rapid Deals,</p>
        <table>
            <tr><td>Name</td><td><?php echo e($username); ?></td></tr>
            <tr><td>Email</td><td><?php echo e($email); ?></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Contact No</td><td><?php echo e($phone); ?></td></tr>
            <tr><td>Query</td><td><?php echo e($query); ?></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Thanks & Regards,</td></tr>
            <tr><td><?php echo e($username); ?></td></tr>
        </table>
    </body>
</html><?php /**PATH /home/b81baw0coev3/public_html/rapidleads.buzzsummo.net/resources/views/emails/contact_query.blade.php ENDPATH**/ ?>