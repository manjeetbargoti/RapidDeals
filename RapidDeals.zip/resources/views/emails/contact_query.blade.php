<html>
    <head>
        <title>A User Generate a Query</title>
    </head>
    <body>
        <p>Hi Rapid Deals,</p>
        <table>
            <tr><td>Name</td><td>{{ $username }}</td></tr>
            <tr><td>Email</td><td>{{ $email }}</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Contact No</td><td>{{ $phone }}</td></tr>
            <tr><td>Query</td><td>{{ $query }}</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Thanks & Regards,</td></tr>
            <tr><td>{{ $username }}</td></tr>
        </table>
    </body>
</html>