<html>
    <head>
        <title>A User Send an Career Enqury</title>
    </head>
    <body>
        <p>Hi Rapid Deals,</p>
        <table>
            <tr><td>Name</td><td>{{ $fullname }}</td></tr>
            <tr><td>Email</td><td>{{ $email }}</td></tr>
            <tr><td>Phone</td><td>{{ $phone }}</td></tr>
            <tr><td>course</td><td>{{ $course }}</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>description</td><td>{{ $description }}</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Thanks & Regards,</td></tr>
            <tr><td>{{ $fullname }}</td></tr>
        </table>
    </body>
</html>